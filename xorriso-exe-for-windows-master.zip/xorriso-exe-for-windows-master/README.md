# xorriso-exe-for-windows

Latest xorriso.exe 1.5.2 pre-build for Windows to make iso disk images to get CD to boot on EFI system

Download Xorriso for Windows here https://github.com/PeyTy/xorriso-exe-for-windows/archive/master.zip

Built directly from unmodified sources
